# 建築風力分析操作影片
## Overview
臺灣耐風規範計算工作台。精確、易讀、以真實操作畫面為核心。
## Colors
Navy #132b42；teal #087b85；paper #edf1f5；white #ffffff；ink #20374c。
## Typography
Source Han Sans TC。本機字型；大標 60px，說明 26px，章節 20px。
## Components
白色操作畫面、深藍側欄、青綠焦點框、時間進度線。
## Assets
六張實際引擎渲染的操作狀態截圖。不是連續螢幕錄影。
## Guardrails
不以範例係數冒充個案查表。無配音，以繁體字幕教學。避免花俏轉場遮蔽控制項。
