繁體字幕教學影片原始檔。需安裝 Source Han Sans TC 字型、Node.js、HyperFrames 0.8.142。執行 npm run check，再執行 npm run render。畫面為實際程式狀態截圖及操作標示，無配音。
