import asyncio, json, pathlib, ssl, subprocess
import edge_tts, edge_tts.communicate

# Add the host's trusted CA bundle without disabling certificate verification.
ca = ssl.get_default_verify_paths().cafile
if ca:
    edge_tts.communicate._SSL_CTX.load_verify_locations(cafile=ca)
config = json.loads(pathlib.Path('narration.json').read_text())
out = pathlib.Path('narration'); out.mkdir(exist_ok=True)

async def main():
    for i, chapter in enumerate(config['chapters']):
        path = out / f'chapter-{i+1:02}.mp3'
        if not path.exists() or path.stat().st_size == 0:
            tts = edge_tts.Communicate(chapter['text'], config['voice'], rate=config['rate'], connect_timeout=20, receive_timeout=40)
            await tts.save(str(path), str(path.with_suffix('.json')))
        duration = float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(path)]))
        print(f'{i+1}: {duration:.3f}s — {chapter["title"]}', flush=True)

asyncio.run(main())
