# Audio

Voice: zh-TW-HsiaoChenNeural (Female, Taiwanese Mandarin), rate -5%. Synthetic narration.

`narration.mp3` is the complete aligned 120-second audio track used by `index.html`. `narration/` preserves the original eight TTS MP3 files and returned sentence timings. `narration.json` contains the script and chapter timing. Each chapter has 0.55 seconds of leading silence and is padded to 15 seconds, then the complete track is normalized to a target of -18 LUFS and a true-peak limit of -1.5 dB.

`python3 generate_narration.py` can regenerate missing raw clips after installing `edge-tts` and FFmpeg; generation requires network access. Existing complete audio plays and renders offline.

`npm run check` and `npm run render` use the pinned HyperFrames version. The released MP4 uses the unchanged original H.264 video stream plus the normalized narration encoded as AAC 48 kHz mono.
